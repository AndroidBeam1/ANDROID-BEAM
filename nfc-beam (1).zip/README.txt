NFC Beam: install on BOTH phones. One taps Send, the other taps Receive, then touch their backs together.
