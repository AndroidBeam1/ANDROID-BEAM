package com.example.nfcbeam

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator

/** Pulsing rings, a nod to the old Android Beam animation. */
class BeamView(context: Context) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    var active = false
        set(v) {
            field = v
            if (v) anim.start() else { anim.cancel(); t = 0f; invalidate() }
        }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val max = minOf(width, height) / 2f
        val color = if (active) 0xFF4FC3F7.toInt() else 0xFF546E7A.toInt()
        if (active) {
            for (i in 0..2) {
                val f = (t + i / 3f) % 1f
                ring.color = color
                ring.alpha = ((1f - f) * 255).toInt()
                c.drawCircle(cx, cy, max * 0.25f + max * 0.7f * f, ring)
            }
        }
        core.color = color
        c.drawCircle(cx, cy, max * 0.22f, core)
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }
}
